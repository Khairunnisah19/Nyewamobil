<?php
  mysql_connect("localhost","root","") or die("error koneksi");
  mysql_select_db("twd_ajaxsearch") or die("error pilih db");
?> 